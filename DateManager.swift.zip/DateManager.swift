//
//  DateManager.swift
//
//
/**
 This class manages all date related task
 */
import Foundation

enum DateFormateStrings: String {
   case defaultSwift = "yyyy-MM-dd'T'HH:mm:ssZ"
}


//Provides some default timezones
struct TimeZones {
    static var UTC: TimeZone { get { return TimeZone(abbreviation: "UTC")! } }
    static var EST: TimeZone { get { return TimeZone(abbreviation: "EST")! } }
    static var IST: TimeZone { get { return TimeZone(abbreviation: "IST")! } }
}



class DateManager: NSObject {
    // Date formatter for managing dates
    private static let dateFormatter = DateFormatter()
    
    //Returns current utc datetime
    static var currentUTCDateTime: Date? { get { return Date() } }
    
    // Returns current localDateTime
    static var currentLocalDateTime: Date? {
        get {
            dateFormatter.timeZone = .current
            dateFormatter.dateFormat = DateFormateStrings.defaultSwift.rawValue
            let dateString = dateFormatter.string(from: Date())
            return dateFormatter.date(from: dateString)
        }
    }
    
    //Returns month name
    static func getMonthName(from date:Date?, characterLength:Int?) -> String? {
        guard let date = date else { return nil }
        dateFormatter.dateFormat = "LLLL"
        var monthName = dateFormatter.string(from: date)
        if let characterLength = characterLength {
            monthName = String(monthName.prefix(characterLength))
        }
        return monthName
    }
    
    static func getDate(from date:Date?, characterLength:Int?) -> String? {
        guard let date = date else { return nil }
        dateFormatter.dateFormat = "dd.MM.yy"
        var dateName = dateFormatter.string(from: date)
        if let characterLength = characterLength {
            dateName = String(dateName.prefix(characterLength))
        }
        return dateName
    }
    
    

    
    static func getShortMonthName(from date:Date?, characterLength:Int?) -> String? {
        guard let date = date else { return nil }
        dateFormatter.dateFormat = "LLL"
        var monthName = dateFormatter.string(from: date)
        if let characterLength = characterLength {
            monthName = String(monthName.prefix(characterLength))
        }
        return monthName
    }
    
    //Returns year
    static func getYear(from date:Date?, isShortForm: Bool) -> Int? {
        guard let date = date else { return nil }
        dateFormatter.dateFormat = "yyyy"
        var yearString = dateFormatter.string(from: date)
        if isShortForm {
            yearString = String(yearString.dropFirst(2))
        }
        return Int(yearString)
    }

}
